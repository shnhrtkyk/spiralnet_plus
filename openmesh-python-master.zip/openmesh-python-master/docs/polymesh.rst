
********
PolyMesh
********

.. autoclass:: openmesh.PolyMesh
   :members:
