#!/usr/bin/env python
# encoding: utf-8

# Copyright (c) 2016 Max Planck Society. All rights reserved.
