Mesh viewer
===========


Reference
---------

.. automodule:: psbody.mesh.meshviewer
   :members:
   :undoc-members:
 
